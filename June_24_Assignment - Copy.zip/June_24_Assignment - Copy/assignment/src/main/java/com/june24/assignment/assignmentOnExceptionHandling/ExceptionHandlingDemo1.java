package com.june24.assignment.assignmentOnExceptionHandling;

import java.util.Scanner;

/* Write an application that accepts two numbers, divides the first number with the second
number and display the result. Hint: You need to handle ArithmeticException which is
thrown when there is an attempt to divide a number by zero.
 */
public class ExceptionHandlingDemo1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number: ");
        int num1 = sc.nextInt();

        System.out.println("Enter second number: ");
        int num2 = sc.nextInt();

        try{
            int result = divideNum(num1, num2);

            System.out.println("Result of division: " + result);
        }catch(ArithmeticException e) {
            System.out.println("Error Division by zero is not allowed.");

        }
        sc.close();
        }
        public static int divideNum(int dividend, int divisor){
            if(divisor == 0){
                throw new ArithmeticException("Division by zero");
        }
            return divisor;
    }
}
