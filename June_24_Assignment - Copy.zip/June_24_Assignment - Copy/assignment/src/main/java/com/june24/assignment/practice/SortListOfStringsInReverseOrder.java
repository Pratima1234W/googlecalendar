package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SortListOfStringsInReverseOrder {
    public static void main(String[] args){
        List<String> list = Arrays.asList("apple","apron","banana","mango");
        List<String> list1 = list.stream()
                .sorted(Comparator.reverseOrder())  //custom sorting order
                .collect(Collectors.toList());
        list1.forEach(System.out::println);
    }
}
