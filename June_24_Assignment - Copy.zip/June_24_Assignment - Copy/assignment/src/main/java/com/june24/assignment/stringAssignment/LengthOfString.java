package com.june24.assignment.stringAssignment;
/* Write an application to determine the length of the String str = “Hello World”. (Hint: Use
String method)
*/
public class LengthOfString {
    public static void main(String[] args){
        String str = "Hello World";
       System.out.println("length of String : " + str.length());

    }
}
