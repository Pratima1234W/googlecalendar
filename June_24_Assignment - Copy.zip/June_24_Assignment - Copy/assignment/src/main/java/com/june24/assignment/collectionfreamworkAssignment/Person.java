package com.june24.assignment.collectionfreamworkAssignment;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/*Write a class Person having weight, height & name. Create
multiple person objects & print them in the sorted order. In the sorting order first sort
based upon their weight & it two persons have same weight them sort them based upon
their height. Use TreeSet.*/
class Person implements Comparable<Person> {
    private int height;
    private int weight;
    private String name;


    public Person(String name, int height, int weight){
        this.name = name;
        this.height = height;
        this.weight = weight;
    }

    public String getName(){
        return name;
    }

    public int getHeight(){
        return height;
    }

    public int getWeight(){
        return weight;
    }
    //To define the natural ordering of Person object
    @Override
    public int compareTo(Person other){
        int weightComparison = Integer.compare(this.weight, other.weight);
        if(weightComparison != 0){
            return weightComparison;
        }
        return Integer.compare(this.height, other.height);
    }

    @Override
    public String toString() {
        return "Person{" +
                "height=" + height +
                ", weight=" + weight +
                ", name='" + name + '\'' +
                '}';
    }
}

 class PersonSorting{
    public static void main(String[] args){

        Set<Person> persons = new TreeSet<>();
        persons.add(new Person("XYZ", 70, 165));
        persons.add(new Person("XYZ", 70, 175));
        persons.add(new Person("XYZ", 80, 180));
        persons.add(new Person("XYZ", 60, 160));

        persons.forEach(System.out::println);
    }

}