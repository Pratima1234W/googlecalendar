package com.june24.assignment.stringAssignment.stringBuilder;

/*Note: StringBuilder: J2SE 5 adds a new string class to Java’s already powerful string handling
        capabilities. This new class is called StringBuilder. It is identical to StringBuffer except for one
        important difference: it is not synchronized, which means that it is not thread safe. The advantage
        of StringBuilder is faster performance. However, in cases in which you are using multithreading,
        you must use StringBuffer rather than StringBuilder.
        1) Provide solution for “Assignments on StringBuffer Class” using StringBuilder clas*/
public class StringBuilder1 {
    public static void main(String[] args){
        StringBuilder stringBuilder = new StringBuilder("Hello");
        stringBuilder.append("Java");       //append text
        stringBuilder.insert(6,"Learning");     //insert text at a specific position
        stringBuilder.replace(12,17,"StringBuilder");
        stringBuilder.delete(5, 6);
        stringBuilder.reverse();
        String finalString = stringBuilder.toString();          //print the final string
        System.out.println("Final String: " + finalString);

    }
}
