
package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;

class ElderPersonFinder{
    public static void main(String[] args){
        List<Person> persons = Arrays.asList();
    }
        }

 class Person {

    int id;
    int age ;

    @Override
    public String toString() {
        return "ElderPersons{" +
                "id=" + id +
                ", age=" + age +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}



