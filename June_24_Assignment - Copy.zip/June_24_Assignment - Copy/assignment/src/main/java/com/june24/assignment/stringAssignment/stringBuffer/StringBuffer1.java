package com.june24.assignment.stringAssignment.stringBuffer;
/* Write an application to append the following strings “StringBuffer”, “is a peer class of
String”, “that provides much of “, “the functionality of strings” using a StringBuffer. */
public class StringBuffer1 {
    public static void main(String[] args){
        StringBuffer sb = new StringBuffer();
        sb.append("StringBuffer");
        sb.append("is a peer class of String");
        sb.append("that provides much of ");
        sb.append("the functionality of strings");

        String msg = sb.toString();
        System.out.println(msg);
    }
}



