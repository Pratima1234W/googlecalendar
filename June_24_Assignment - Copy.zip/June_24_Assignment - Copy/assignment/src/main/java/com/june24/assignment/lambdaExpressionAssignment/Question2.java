package com.june24.assignment.lambdaExpressionAssignment;

import java.util.ArrayList;
import java.util.List;

/*write an application using lambda expression to print Orders having 2 criteria implemented 1) order
 price more than 10000 2) order status is ACCEPTED or COMPLETED*/
public class Question2 {
         private final int orderId;
         private final double orderPrice;
         private final String orderStatus;

         public Question2(int orderId, double orderPrice, String orderStatus){
             this.orderId = orderId;
             this.orderPrice = orderPrice;
             this.orderStatus = orderStatus;
        }

        public int getOrderId(){
             return orderId;
    }
        public double getOrderPrice(){
             return orderPrice;
        }

        public String getOrderStatus(){
             return orderStatus;
        }

    @Override
    public String toString() {
        return "Question2{" +
                "orderId=" + orderId +
                ", orderPrice=" + orderPrice +
                ", orderStatus='" + orderStatus + '\'' +
                '}';
    }
    public static void main(String[] args){
        List<Question2> orders = new ArrayList<>();
        orders.add(new Question2(1, 15000.0, "ACCEPTED"));
        orders.add(new Question2(1, 9000.0, "PENDING"));
        orders.add(new Question2(1, 12000.0, "COMPLETED"));
        orders.add(new Question2(1, 8000.0, "ACCEPTED"));

        printFilteredOrders(orders);
    }
    private static void printFilteredOrders(List<Question2> orders){
             orders.stream()
                     .filter(order -> order.getOrderPrice() > 10000.0)
                     .filter(order -> order.getOrderStatus().equals("ACCEPTED") ||
                             order.getOrderStatus().equals("PENDING") ||
                             order.getOrderStatus().equals("COMPLETED"))
                     .forEach(System.out::println);
    }
}