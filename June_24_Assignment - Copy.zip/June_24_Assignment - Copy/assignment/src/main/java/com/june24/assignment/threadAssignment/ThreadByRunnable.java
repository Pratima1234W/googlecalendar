package com.june24.assignment.threadAssignment;

public class ThreadByRunnable implements Runnable{

    @Override
     public void run(){
        for(int i = 0; i < 3; i++){
            System.out.println("value of i is: " +i);
        }
    }
    public static void main(String[] args){
        ThreadByRunnable obj = new ThreadByRunnable();
        Thread t = new Thread(obj);
        t.start();
    }
}
