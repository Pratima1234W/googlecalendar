package com.june24.assignment.apac;
/* input : Welcome to Capgemini
 output : WeLcOmE tO cApGeMiNi*/
public class Demo {
    public static void main(String[] args){
        String str1 = "Welcome to Capgemini";
        StringBuilder stringBuilder = new StringBuilder();

        for(int i = 0; i< str1.length(); i++){
            char ch = str1.charAt(i);
            if(i % 2 == 0){
                stringBuilder.append(Character.toUpperCase(ch));
            }else{
                stringBuilder.append(Character.toLowerCase(ch));
            }
        }
        System.out.println(stringBuilder.toString());
    }
}
