package com.june24.assignment.collectionfreamworkAssignment;

import java.util.ArrayList;
import java.util.ListIterator;

/* Create a ArrayList with few elements & print it in backward
direction. Use ListIterator */
public class UnitThree {
    public static void main(String[] args){
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("list1");
        arrayList.add("list2");
        arrayList.add("list3");
        arrayList.add("list4");

        ListIterator<String> listIterator = arrayList.listIterator(arrayList.size());
        System.out.println(arrayList.size());

        while(listIterator.hasPrevious()){
            String s = listIterator.previous();
            System.out.println(s);
        }
    }
}
