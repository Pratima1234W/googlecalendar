package com.june24.assignment.collectionfreamworkAssignment;

/*COLLECTION FRAMEWORK: Prove that HashSet is unordered & LinkedHashSet is
   ordered.*/

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class UnitTwo {
    public static void main(String[] args) {
        HashSet<String> hashSet = new HashSet<>();
        LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();

        for (String str : Arrays.asList("order1", "order2", "order3", "order4")) {

            hashSet.add(str);
            linkedHashSet.add(str);

            System.out.println("Insertion Order" + "of object in HashSet :" + hashSet);
            System.out.println("Insertion Order" + "of object in LinkedHashSet :" + linkedHashSet);

        }
    }
}
