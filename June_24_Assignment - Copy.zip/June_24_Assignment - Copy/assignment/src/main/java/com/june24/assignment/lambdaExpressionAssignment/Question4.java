package com.june24.assignment.lambdaExpressionAssignment;

import java.util.ArrayList;
import java.util.List;

/* Remove the words that  have odd length from the list. Hint: use one of the new method JDK8, use
removeIf() method from Collection Interface*/
public class Question4 {
    public static void main(String[] args){
        List<String> words = new ArrayList<>();
        words.add("hello");
        words.add("world");
        words.add("java");
        words.add("programming");
        words.add("code");

        System.out.println(" Original List : " + words);

        words.removeIf(word -> word.length() % 2 != 0);

        System.out.println("List after removing words with odd length:" +words);

    }
}
