package com.june24.assignment.interceptorDemo;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

 /* Interceptor creation*/
@Component
public class MyInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception{
        //code executed before the controller
        System.out.println("Pre- handle method is calling");

        //returning true to let the request proceed to the controller
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView)throws Exception{
        // code executed after the controller but before the view is rendered
        System.out.println("Post-handler method is calling: ");
    }

    @Override
    public void afterCompletion(HttpServletRequest request,HttpServletResponse response, Object handler,
                                Exception exception)throws Exception{
        // code executed after the complete request has finished
        System.out.println("Request and Response completed:");
    }

}
