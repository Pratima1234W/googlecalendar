package com.june24.assignment.practice.arrayspractice;

import java.util.ArrayList;

public class ArrayDemo {

    public static void main(String[] args){
        int[] arr = new int[2];
        arr[0] = 5;
        arr[1] = 9;

        System.out.println(arr[0]);

        //creating Arraylist with capacity 2

        ArrayList<Integer> arrL = new ArrayList<>(2);
        arrL.add(1);
        arrL.add(2);

        System.out.println(arrL.get(0));

    }
}
