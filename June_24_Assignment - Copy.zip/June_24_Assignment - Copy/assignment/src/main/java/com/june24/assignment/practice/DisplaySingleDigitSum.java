/*
package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;

public class DisplaySingleDigitSum {
    public static void main(String[] args){
        List<Integer> num = Arrays.asList(1, 2, 3, 4, 5);
        String sum = num.stream()
                .map()


        System.out.println("Input : " + num);
        System.out.println("Sum: " + sum);
    }
}

*/
