package com.june24.assignment.lambdaExpressionAssignment;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/* Create a new thread that prints the number from the list. Use class Thread & interface Consumer*/
public class Question8 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        //consumer defined which prints number
        Consumer<Integer> printNumber = num -> System.out.println("Number : " + num);

        //Runnable that iterates over the list and applies the consumer
        Runnable task = () -> {
            for (Integer num : numbers) {
                //accept() performs operation on given number.
                printNumber.accept(num);
            }
        };
        //create Thread with Runnable

        Thread thread = new Thread(task);
        thread.start();
    }
}
