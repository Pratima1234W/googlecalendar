package com.june24.assignment.collectionfreamworkAssignment;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/* Write a program using Hashtable or HashMap where Date
of birth is a key & Employee name as value. Design the class Date is such a way where
the get method fails if two employees have same day & month of birth but birth year is
different.
*/
public class Date {
    private int day;
    private int month;
    private int year;

    public Date(int day, int month, int year){
        this.day = day;
        this.month = month;
        this.year = year;
    }

    public int getDay() {
        return day;
    }

    public int getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Date date = (Date) o;
        return day == date.day && month == date.month;
    }

    @Override
    public int hashCode() {
        return Objects.hash(day, month);
    }

    @Override
    public String toString() {
        return "Date{" +
                "day=" + day +
                ", month=" + month +
                ", year=" + year +
                '}';
    }
}

class Employees {
    public static void main(String[] args) {
        Map<Date, String> map = new HashMap<>();

        addEmployee(map, new Date(15, 7, 1990), "John");
        addEmployee(map, new Date(1, 6, 1995), "Mohan");
        addEmployee(map, new Date(15, 7, 1990), "Hari");
        addEmployee(map, new Date(10, 7, 1990), "Shiv");

       map.forEach((key, value)->System.out.println(key + " : " + value));

       /* for(Map.Entry<Date, String> entry : map.entrySet()){
            System.out.println("Date of Birth : " + entry.getKey() + ", entry.getValue()");
        }*/

    }
    public static void addEmployee(Map<Date, String> map, Date date, String name) {
        if (map.containsKey(date)) {
            System.out.println("Error: Another employee with the same day and month of birth exists:" + name);
        } else {
            map.put(date, name);
        }
    }
}

