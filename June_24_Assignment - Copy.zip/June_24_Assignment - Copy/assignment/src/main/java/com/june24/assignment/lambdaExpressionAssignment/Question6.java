package com.june24.assignment.lambdaExpressionAssignment;

import java.util.Arrays;
import java.util.List;
import java.util.function.UnaryOperator;

/* Replace every word in the list with its upper case equivalent. Use replaceAll() methods and
UnaryOperator interface*/
public class Question6 {
    public static void main(String[] args){
        List<String> words = Arrays.asList("java","learning");
        System.out.println("Original list :" +words);

        UnaryOperator<String> toUpperCase = String :: toUpperCase;
        words.replaceAll(toUpperCase);

        System.out.println("Updated list :" +words);
    }
}
