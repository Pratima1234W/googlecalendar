package com.june24.assignment.practice;

import java.util.Scanner;

public class TopMostClass {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your class name : ");
        String givenClassName = sc.next();
        System.out.println(givenClassName);
        System.out.println("***********************");
        try{

        }catch(Exception e){
            System.out.println("Error:");
            System.out.println(e.getMessage());
        }
    }
}
