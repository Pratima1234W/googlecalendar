package com.june24.assignment.apac;
/* write a program to convert upper case string to lower case*/
public class Case {
    public static void main(String[] args){
        String str = "write java program";
        String str1 = str.toUpperCase();
        System.out.println(str1);

    }
}
