package com.june24.assignment.lambdaExpressionAssignment;

import java.util.HashMap;
import java.util.Map;

/* Convert every key-value pair of the map into String and append them all into a single string,
 in iteration order.Hint: Use Map.entrySet() method and a StringBuilder to construct the result string*/
public class Question7 {
    public static void main(String args[]){
        Map<Integer, String> map = new HashMap<>();
        map.put( 1, "value");
        map.put( 2, "value");
        map.put( 3, "value");
        map.put( 4, "value");
        StringBuilder result = new StringBuilder();

        for(Map.Entry<Integer, String> entry : map.entrySet()){
            result.append(entry.getKey()).append(entry.getValue()).append(" ");
        }
        String resultString = result.toString().trim();
        System.out.println("Resulting string : " + resultString);
    }
}
