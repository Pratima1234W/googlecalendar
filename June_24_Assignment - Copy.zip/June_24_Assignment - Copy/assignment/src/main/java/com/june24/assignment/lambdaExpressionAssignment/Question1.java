package com.june24.assignment.lambdaExpressionAssignment;
 /* write a program to perform basic arithmetic operations
   1. Need to define functional interface first*/

@FunctionalInterface
interface  ArithmeticOperations{
    int operations(int a, int b);
}
public class Question1 {
    public static void main(String[] args){
        ArithmeticOperations addition = (a, b) -> a + b;
        System.out.println(addition.operations(2,2));

        ArithmeticOperations subtraction = (a, b) -> a - b;
        System.out.println(subtraction.operations(2, 2));

        ArithmeticOperations product = (a, b) ->a * b;
        System.out.println(product.operations(2, 2));

        ArithmeticOperations division = (a, b) -> a / b;
        System.out.println(division.operations(2, 2));
    }
}
