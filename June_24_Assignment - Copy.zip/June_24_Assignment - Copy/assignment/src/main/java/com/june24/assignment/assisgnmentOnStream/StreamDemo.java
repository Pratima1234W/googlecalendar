package com.june24.assignment.assisgnmentOnStream;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Fruit { String name; int calories; int price; String color;
        public Fruit(String name, int calories, int price, String color){
            this.name = name;
            this.calories = calories;
            this.price = price;
            this.color = color;
        }

        public String getName(){
            return name;
        }

        public int getCalories(){
            return calories;
        }

        public int getPrice(){
            return price;
        }

        public String getColor(){
            return color;
        }


}
class News { int newsId; String postedByUser; String commentByUser; String
        comment; }
class Trader { String name; String city; }
class Transaction { Trader trader; int year; int value; }
public class StreamDemo {
    public static void main(String[] args){

        List<Fruit> fruits = Arrays.asList(
                new Fruit("Apple", 90, 50, "Red"),
                new Fruit("Orange", 80, 60, "Orange"),
                new Fruit("Banana", 105, 20, "Yellow"),
                new Fruit("Grapes", 90, 100, "Green"),
                new Fruit("Cherry", 90, 50, "Red")
        );

        /* Display the fruit names of low calories fruits i.e. calories < 100 sorted in
        descending order of calories */

        List<String> lowCaloriesFruit = fruits.stream()
                                                .filter(fruit -> fruit.getCalories() < 100)
                .sorted(Comparator.comparingInt(Fruit::getCalories).reversed())
                .map(Fruit::getName)
                .collect(Collectors.toList());
        System.out.println("Low calories fruits:"+lowCaloriesFruit);

        // Display color wise list of fruit names.
        Map<String, List<String>> colorWiseFruit = fruits.stream()
                .collect(Collectors.groupingBy(Fruit::getColor,
                        Collectors.mapping(Fruit::getName, Collectors.toList())));
        System.out.println("color wise list of fruit names:"+colorWiseFruit);

        // Display only RED color fruits sorted as per their price in ascending order

        List<String> redColorFruit = fruits.stream()
                .filter(fruit -> "Red".equalsIgnoreCase(fruit.getColor()))
                .sorted(Comparator.comparingInt(Fruit::getPrice))
                .map(Fruit::getName)
                .collect(Collectors.toList());
        System.out.println("only RED color fruits sorted as per their price:"+redColorFruit);

    }
}
