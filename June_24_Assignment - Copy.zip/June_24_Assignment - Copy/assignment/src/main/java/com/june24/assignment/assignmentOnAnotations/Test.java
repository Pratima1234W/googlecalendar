package com.june24.assignment.assignmentOnAnotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)         //make the annotation accessible at runtime
@Target(ElementType.METHOD)                 //specify that the annotation only be applied to methods

public @interface Test {
    String description()
            default "";
}
