package com.june24.assignment.stringAssignment;
/* Write an application to join the two Strings “Hello, ” & “How are you?” (Hint: Use String
method)
*/
public class JoinTwoStrings {
    public static void main(String[] args){
        String str1 = "Hello,";
        String str2 = "How are you?";

        System.out.println(str1.concat(str2));


    }
}
