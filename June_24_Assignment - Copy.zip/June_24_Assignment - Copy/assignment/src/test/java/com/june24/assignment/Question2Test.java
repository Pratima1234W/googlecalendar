package com.june24.assignment;

import com.june24.assignment.assignmentOnAnotations.Test;
import com.june24.assignment.lambdaExpressionAssignment.Question2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import static org.assertj.core.api.Assertions.assertThat;

/* assertThat to check that the filtered list has the expected size and content
*  and extracted method is used to extract the orderId field from the filtered Question2 object
*  and check that the list contains the expected order IDs*/

public class Question2Test {

    @Test
    void testPrintFilteredOrder(){
        List<Question2> orders = new ArrayList<>();
        orders.add(new Question2(1,15000.0,"Accepted"));
        orders.add(new Question2(2,2000.0,"Pending"));
        orders.add(new Question2(3,12000.0,"Completed"));
        orders.add(new Question2(4,8000.0,"Accepted"));

        List<Question2> filteredOrders = getFilteredOrders(orders);
        assertThat(filteredOrders).hasSize(2);
        assertThat(filteredOrders).extracting(Question2::getOrderId).containsExactly(1, 3);
    }

    private List<Question2> getFilteredOrders(List<Question2> orders){
        return orders.stream()
                .filter(order -> order.getOrderPrice() > 10000)
                .filter(order -> order.getOrderStatus().equals("Accepted") ||
                        order.getOrderStatus().equals("COMPLETED"))
                .collect(Collectors.toList());
    }
}
