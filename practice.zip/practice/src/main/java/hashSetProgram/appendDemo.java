package hashSetProgram;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

/*1. Write a Java program to append the specified element to the end of a hash set.=>
The set variable is immutable in terms of its reference (it cannot be reassigned),
 but its contents can still change.**The set variable can be reassigned to a different Set object if needed.
In practical terms, the behavior of both programs will be the same when it comes to
modifying the contents of the HashSet, but the first program has a constraint on reassigning set itself.*/

public class appendDemo {
    public static void main(String[] args) {
        Set<Integer> set2 = new HashSet<>();
        set2.add(100);
        set2.add(500);
        Set<Integer> set = new HashSet<>();
        set.add(1);
        set.add(5);
        set.add(20);
        set.add(23);
        set.add(50);
        int elementToAdd = 3;
        System.out.println(elementToAdd);
        System.out.println(set);
        /*2. Write a Java program to iterate through all elements in a hash list.*/
        //method1 : using forEach loop
        for (Integer element : set) {
            System.out.println(element);
        }

        //method2 : using iterator
        System.out.println("\n iterating using iterator:");
        Iterator<Integer> iterator = set.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
        // Method 3: Using Java 8 forEach with a lambda expression
        System.out.println("using java8 forEach");
        set.forEach(elements -> System.out.println(elements));

        /* 3. Write a Java program to get the number of elements in a hash set.*/
        System.out.println("hash set size is:"+ set.size());

/*        4. Write a Java program to empty an hash set.*/
       // System.out.println("empty hashset:"+set.removeAll(set));
        System.out.println("check for empty hashset:"+set.isEmpty());

        /*6. Write a Java program to clone a hash set to another hash set.*/
        Set<Integer> clonedSet = new HashSet<>(set);
        System.out.println("Original hashset: " + set);
        System.out.println("cloned hashset: " +clonedSet);


        /*7. Write a Java program to convert a hash set to an array.*/
        Integer[] num = new Integer[set.size()];
        set.toArray(num);
        System.out.println("New array element:");
        for(Integer arrayElements : num){
            System.out.println(arrayElements);
        }

        /*8. Write a Java program to convert a hash set to a tree set.*/
        Set<Integer> treeSet = new TreeSet<>(set);
        System.out.println("TreeSet Elements are:");
        for(Integer treeSetElements:treeSet){
            System.out.println(treeSetElements);
        }

        /*9. Write a Java program to find numbers less than 7 in a tree set.*/
        System.out.println("numbers less than 7 in treeSet:");
        for(Integer count : treeSet){
            if(count < 7){
                System.out.println(count);
            }
        }

        /*10. Write a Java program to compare two hash set.*/
        System.out.println("set and set2 are equal: " +set.equals(set2) );

        /*11. Write a Java program to compare two sets and retain elements that are the same.*/
        System.out.println("if set and set2 not same then retain elements that are the same:" +set.retainAll(set2));
        System.out.println(set2);

    }
}
