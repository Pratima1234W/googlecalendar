package com.logic.practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateNumbers {
    public static void main(String[] args){
        List<Integer> listNumbers = Arrays.asList(1,45,1,6,8,9,45);
        List<Integer> uniqueNumbers = listNumbers.stream()
                .distinct()
                .collect(Collectors.toList());
        System.out.println(uniqueNumbers);
    }
}
