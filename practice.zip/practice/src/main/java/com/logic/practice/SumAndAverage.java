package com.logic.practice;

public class SumAndAverage {
    public static void main(String[] args){
        int[] numbers = {2,4,8,6,10};
        int sum = 0;
        for(int number: numbers){
            sum= number +1;
        }
       // double avg = sum / numbers.length;
//        System.out.println(avg);
        System.out.println(sum);

    }
}
