package com.logic.practice;

public class Demo {
    public static void main(String[] pavan){
    String input = "name";
    StringBuilder builder = new StringBuilder();
        for(int i = 0; i < input.length(); i++){
        builder.append("@").append(input.charAt(i));
    }
        System.out.println(builder.toString());
}
}
