package com.logic.practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class DecimalsInReverseOrder {
    public static void main(String[] args){
        List<Double> list = Arrays.asList(20.5, 66.2, 11.4, 2.2);
        list.stream()
                .sorted(Comparator.reverseOrder())
                .forEach(System.out::println);
    }
}
