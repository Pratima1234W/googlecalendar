package com.logic.practice;

public class AfterTwoCharAddSymbol {
    public static void main(String[] args){
        String input = "input";
        StringBuilder builder = new StringBuilder();
        for(int i =0; i < input.length(); i++){
            builder.append(input.substring(i, i+1)).append("@");
        }
        System.out.println(builder.toString());
    }
}
