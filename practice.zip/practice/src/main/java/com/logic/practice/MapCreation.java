package com.logic.practice;

import org.springframework.beans.factory.annotation.Value;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class MapCreation {
    public static void main(String[] args) {
        //create map using hashmap
        Map<Integer, String> map = new HashMap<>();
        //inserting pair using put()
        map.put(1, "Smith");
        map.put(2, "Ashok");
        map.put(4, "Ali");
        map.put(3, "kivi");
        //by using entrySet() to get the set view
        /*for (Map.Entry<Integer, String> ma : map.entrySet()) {
            System.out.println(ma.getKey());
            System.out.println(ma.getValue());
            System.out.println(map);
        }*/
        //Iterate over a map using for each
        map.forEach((key, value)-> System.out.println("key: " + key + ", value: " +value ));

        //filter a map based on values
       /* Map<Integer, String> filteredMap = map.entrySet()
                .stream()
                .filter(entry ->)
                .collect(Collectors.toList());*/
    }
}
