package com.logic.practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicateElements {
    public static void main(String[] args) {
        List<String> listOfString = Arrays.asList("Java", "C++", "Java", "ReactJs", "ReactJs");
        List<String> uniqueString = listOfString.stream()
                .distinct()
                .collect(Collectors.toList());
        System.out.println(uniqueString);
    }
}
