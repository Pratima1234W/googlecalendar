package com.logic.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

//Separate odd and even numbers from the list
public class OddAndEven {

    public static void main(String[] args){
        List<Integer> list = Arrays.asList(71,18, 42, 21, 67, 32, 14, 56, 87);

        //separate odd and even number in to a map
        Map<Boolean,List<Integer>> map = list.stream()
                .collect(Collectors.partitioningBy(num -> num % 2 == 0));

        //even and odd lists
        List<Integer> evenNumber = map.get(true);
        List<Integer> oddNumber = map.get(false);

        //print result
        System.out.println("Even Number: " + evenNumber);
        System.out.println("odd Number: " + oddNumber);
    }
}
