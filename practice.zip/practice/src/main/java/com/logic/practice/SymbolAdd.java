package com.logic.practice;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SymbolAdd {
    public static void main(String[] args){
        String input = "input";
        String result = Stream.of(input.split(""))
                //.map(c -> c + "&")
                .map(c -> "&" + c)
                .collect(Collectors.joining());
        System.out.println(result);
    }
}
