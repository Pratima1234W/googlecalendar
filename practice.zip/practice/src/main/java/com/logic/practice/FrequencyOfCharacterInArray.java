package com.logic.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FrequencyOfCharacterInArray {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("pen", "pen", "pencil", "pages");
        Map<String, Long> frequency = list.stream()
                .collect(Collectors.groupingBy(item -> item, Collectors.counting()));
        System.out.println(frequency);
    }

}
