package com.logic.practice;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FrequencyOfCharacterInString {
    public static void main(String[] args){
        String inputString = "Pratima";
        Map<Character, Long> frequency = inputString.chars()
                .mapToObj(c -> (char)c)
                .collect(Collectors.groupingBy(item -> item, Collectors.counting()));
        frequency.forEach((key, value)->System.out.println(key +":"+ value));

       // System.out.println(frequency);
    }
}
