package com.logic.practice;

public class StringLength {
    public static void main(String[] args){
        String str = "input";
        System.out.println(str.length());
    }
}
