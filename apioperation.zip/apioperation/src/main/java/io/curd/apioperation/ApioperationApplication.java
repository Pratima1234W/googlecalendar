package io.curd.apioperation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApioperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApioperationApplication.class, args);
	}

}
