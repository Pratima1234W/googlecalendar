package io.curd.apioperation.services;

import io.curd.apioperation.entities.User;

import java.util.List;

public interface UserService {
    //Save operations
    User saveUser(User user);

    //fetch user details
    List<User> fetchUserList();

    //update user details
    User updateUser(User user, Long userId);

    //Delete operations
    void deleteUserById(User user, Long userId);

    User createUser(User user);

}
