package com.example.demo.entities;

import jakarta.persistence.Entity;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@Entity
public class Employee {
    int empId;
    String empName;
    double empSalary;
    int depid;
}
