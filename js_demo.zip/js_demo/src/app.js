import $ from 'jquery';
import { fleet } from './fleet-data.js';
import { FleetDataService } from './services/fleet-data-service.js';
import { ApplicationBase } from './freamwork/application-base.js';
/* import { Car } from './classes/car.js';
import { Drone } from './classes/drone.js'; 
import {Button} from './ui/button.js';  */

export class App extends ApplicationBase{
    constructor(){
        super('Fleet Manager');
        this.dataService = new FleetDataService();
        this.dataService.loadData(fleet);

        this.addRoot('Home', new HomePage(), true);
        this.addRoot('Cars', null);
        this.addRoot('Drones', null);
        this.addRoot('Map', null);
    }
}

export let application = new App();
application.show($('body'));

/* let b = new Button('Click Me');
b.appendToElement($('body'));
//let c = new Car();
//let d = new Drone();

// console.log(c);
// console.log(d);
//console.log(fleet);
//let dataSrvice = new FleetDataService();
//dataSrvice.loadData(fleet);

// for(let e of dataSrvice.errors)
// console.log(e.message);

// let car = dataSrvice.getCarByLicense('E123');
// console.log(car);

//let cars = dataSrvice.getCarSortedByLicense();
//let cars = dataService.filterCarByMake('U');
//for(let car of cars)
//console.log(car.make); */



