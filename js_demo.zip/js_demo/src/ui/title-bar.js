import { BaseElement } from "./base-element";

export class TitleBar extends BaseElement{
    costructor(fileName){
        super();
        this.fileName = fileName;
    }

    /* getElementString(){
        return
        <img
    } */
}