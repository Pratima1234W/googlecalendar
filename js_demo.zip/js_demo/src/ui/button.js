import { BaseElement } from "./base-element";

export class Button extends BaseElement{
    constructor(title){
        super();
        this.title = title;
        this.styleString = '';
    }

    getElementString(){
        return `
            <button class="mdl-button mdl-js-button mdl-button--fab mdl-button--colored">
                ${this.title}
            </button>
            `;
    }

    set styleString(style){
        this.styleString = style;
    }
}