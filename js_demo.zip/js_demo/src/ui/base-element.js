import $ from 'jquery';

export class BaseElement{

    constructor(){
        this.element = null; //jquery object
    }
    appendToElement(e1){
        this.createElement();
        e1.append(this.element);
        this.enableJS();
    }
    createElement(){
        let s = this.getElementString();
        this.element = $(s);
    }
    getElementString(){
        throw 'please override getElementString() in BaseElement'
    }

    enableJS(){
        componentHandler.upgradeElement(this.element[0]);
    }

}