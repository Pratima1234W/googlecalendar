
export class DataError{
    constructor(message, data){
        this.message = message;
        this.data = data;

    }
}