import { TitleBar } from "../ui/title-bar";

export class ApplicationBase{
    constructor(title){
        this.title = title;
        this.TitleBar = new TitleBar(this.title);
        this.routeMap = {};
        this.defaultRout = null;
    }

    addRoot(id, pageObject, defaultRout = false){
        this.titleBar.addLink(id, '');

        this.routeMap[id] = pageObject;

        if(defaultRout){
            this.defaultRout=id;
        }
    }

    show(element){
        this.titleBar.appendToElement(element);
    }
}