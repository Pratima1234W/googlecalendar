export let fleet = [
    {
        license: 'A123',
        type: 'drone',
        model:'Amezon123',
        airTimeHours: '6050',
        base: 'New York',
        latLong:'40.775566 - 73.964350'
    },
    {
        license: 'B123',
        type: 'drone',
        model:'Amezon124',
        airTimeHours: '6040',
        base: 'New York',
        latLong:'40.775566 - 73.964398'
    },
    {
        license: 'C123',
        type: 'drone',
        model:'Google125',
        airTimeHours: '6055',
        base: 'New York',
        latLong:'40.775566 - 73.964300'
    },
    {
        license: 'D123',
        type: 'drone',
        model:'Amezon126',
        airTimeHours: '6050',
        base: 'New York',
        latLong:'40.775566 - 73.964311'
    },
    {
        license: 'E123',
        type: 'car',
        make: 'telsa',
        model:'Quick-transport',
        miles:'15600',
        latLong:'40.775566 - 73.964350'
    },
    {
        license: 'F123',
        type: 'car',
        make: 'telsa',
        model:'Amezon123',
        miles:'15600',
        latLong:'40.775566 - 73.964350'
    }
]