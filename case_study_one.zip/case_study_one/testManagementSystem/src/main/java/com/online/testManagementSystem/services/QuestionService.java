package com.online.testManagementSystem.services;

import com.online.testManagementSystem.models.Questions;
import com.online.testManagementSystem.repositories.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {
    @Autowired
    QuestionRepository questionRepository;

    public Questions save(Questions questions) {
        return questionRepository.save(questions);
    }

    public List<Questions> findAll() {
        return questionRepository.findAll();
    }
}
