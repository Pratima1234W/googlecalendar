package com.online.testManagementSystem.controllers;

import com.online.testManagementSystem.models.Questions;
import com.online.testManagementSystem.services.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/questions")
public class QuestionController {
    @Autowired
    QuestionService questionService;

    @PostMapping("/create")
    public Questions createQuestion(@RequestBody Questions questions) {
        return questionService.save(questions);
    }

    @GetMapping("/allquestions")
    public List<Questions> getAllQuestions(){
        return questionService.findAll();
    }


}
